Tutorial: How to set up React, webpack, and Babel 7 from scratch (2019)


https://www.valentinog.com/blog/babel/

How to pass an object from one component to another
How to pass a function from parent component to child component using the object.
http://www.habilelabs.io/3-simple-steps-create-react-js-components/

