import React, { Component } from 'react'

import { connect } from 'react-redux'

class Home extends Component {

    handleClick = () =>{
        //console.log(this.props.posts[0].id);
        this.props.deletePost(this.props.posts[0].id)
    }

    render() {
        //console.log('all props' + this.props);
        const {posts} = this.props;
        const listItems = posts.map(post => (
            <div key={post.id}>
                <h1>{post.title}</h1>
                <p>{post.body}</p>
                <button onClick={this.handleClick}>DELETE {post.id}</button>
            </div>
        ))

        return(
            <div className="App">
            {listItems}
            
            <hr/>
            {/* <form>
                <label>Id:</label>
            </form> */}
            </div>
        )
        
    }

}


const mapStateToProps = (state) => {
    return {
        posts: state.posts
    }       
}

const mapDispatchToProps = (dispatch) => {
    return {
        deletePost : (id) => { dispatch({type: 'DELETE_POST', id : id}) }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)
