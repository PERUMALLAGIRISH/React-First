const initialState = {
    posts : [
        {id:1, title:"hello1", body:"body1"},
        {id:2, title:"hello2", body:"body2"},
        {id:3, title:"hello3", body:"body3"},
    ]
}


const rootReducer = (state = initialState, action) => {
    //console.log('delete action' + action);
    if (action.type === 'DELETE_POST'){
        let newPosts = state.posts.filter(post => {
            return action.id !== post.id
        });
        return {
            ...state,
            posts : newPosts
        }
    }
    return state
}


export default rootReducer;