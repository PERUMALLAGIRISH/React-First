import React from 'react';
import logo from './logo.svg';
import './App.css';
import EX1 from './Hoocks/ex1'
import EX2 from './Hoocks/ex2'

import Home from './Components/home'



function App() {
  return (
    // <div className="App">
    //   {/* <EX1 />
    //   <EX2 /> */}
    //   <Store />
      
    // </div>

    <div>
      <Home />
    </div>
  );
}

export default App;
