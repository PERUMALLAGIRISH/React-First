import {Map} from '../../graphql/Map'

export const ProfileConstants: Map<any> = {
  FIRST_NAME: 'firstName',
  LAST_NAME: 'lastName',
  POSTAL_CODE: 'postalCode',
  TOWN: 'town',
  STREET_NAME: 'streetName',
  STREET_NUMBER: 'streetNumber',
  COUNTRY_NAME: 'countryIsocode',
  TEXT: 'text',
  NUMBER: 'number',
  EMAIL: 'EMAIL',
  PHONE: 'PHONE',
  LANGUAGE: 'LANGUAGE',
  SUCCESS: 'SUCCESS',
  STEP0: 0,
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4
}

export const ProfileEditBillingAddressConstants: Map<any> = {
  DEFAULT_SALUTATION : 'empty',
  DEFAULT_COUNTRY_NAME: 'Switzerland',
  DEFAULT_COUNTRY_CODE: 'CH',
  SMOOTH: 'smooth',
  START: 'start',
  PASSWORD: 'password'
}

export const ProfileEditPasswordConstants: Map<any> = {
  CURRENT_PASSWORD: 'currentPassword',
  NEW_PASSWORD: 'newPassword',
  CONFIRM_PASSWORD: 'confirmPassword',
  NEW_PASSWORD_MIN_LENGTH: 8,
  NEW_PASSWORD_MAX_LENGTH: 20
}
