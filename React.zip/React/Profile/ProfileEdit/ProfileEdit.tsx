import * as React from 'react';
import {
  Account,
  Address,
  BillInfo,
  BillingAddress,
  BillSettings,
  LocalDate,
  Optional,
  PayloadStatus,
  PaymentMethodType,
  SendNameChangeInfoPayload,
  SendVerificationEmailPayload,
  Subscriber,
  UpdateContactInput,
  UpdateContactPayload
} from '../../../model/types.d';
import {
  fetchAccount,
  resetEditProfile,
  sendNameInfo,
  updateContact,
  validateEmail
} from '../ProfileAction';
import {ActionCreatorsMapObject, bindActionCreators, Dispatch} from 'redux';
import {connect} from 'react-redux';
import {Input} from '../../../components/Form/Input/Input';
import {Select} from '../../../components/Form/Select/Select';
import {StickyBar} from '../../../components/StickyBar/StickyBar';
import {Loader} from '../../../components/Loader/Loader';
import DateService from '../../../utils/DateService';
import SegmentService from '../../../utils/SegmentService';
import {Popup} from '../../../components/Popup/Popup';
import caseChange from 'change-case';
import {Button} from '../../../components/Form/Button/Button';
import I18n from '../../../utils/helper/I18n';
import {ProfileConstants} from '../ProfileConstants';
import LanguageService from '../../../utils/LanguageService';
import {Segment} from '../../../model/Segment.enum';
import {ProfileRoutes} from '../ProfileRoutes.enum';
import ValidationService from '../../../utils/ValidationService';
import {History, Location} from 'history';
import {profileService} from '../ProfileService';

export interface ProfileEditProps {
  account: Account;
  updateContactPayload: UpdateContactPayload;
  updateContactPayloadError: Error;
  sendVerificationEmailPayload: SendVerificationEmailPayload;
  sendVerificationEmailPayloadError: Error;
  sendNameChangeInfoPayload: SendNameChangeInfoPayload;
  sendNameChangeInfoPayloadError: Error;
  history: History;
  location: Location;
  updateContact: (updateContactInput: UpdateContactInput) => void;
  emailValidateAction: () => void;
  sendNameInfo: () => void;
  resetEditProfile: () => void;
  fetchAccount(): void;
}

interface ProfileEditState {
  profile: ProfileEditForm;
  isEditProfileLoading?: boolean;
  isNameChangeLoading?: boolean;
  hasTooltip: boolean;
  selectedTooltip: string;
  isDirty: boolean;
  isValid: boolean;
}

export interface ProfileEditForm extends UpdateContactInput {
  [ key: string ]: any
};

class ProfileEdit extends React.Component<ProfileEditProps, ProfileEditState> {
  constructor(props: ProfileEditProps) {
    super(props);
    this.state = {
      profile: {
        email: '',
        phone: '',
        languageCode: undefined
      },
      isDirty: false,
      isValid: true,
      isEditProfileLoading: true,
      isNameChangeLoading: false,
      hasTooltip: false,
      selectedTooltip: ''
    }
  }

  static getDerivedStateFromProps(nextProps: ProfileEditProps, prevState: ProfileEditState): any | null {
    if (nextProps.account && prevState.isEditProfileLoading) {
      return {isEditProfileLoading: false};
    }
    if ((nextProps.sendNameChangeInfoPayload || nextProps.sendNameChangeInfoPayloadError || nextProps.sendVerificationEmailPayload || nextProps.sendVerificationEmailPayloadError) && prevState.isNameChangeLoading) {
      return {isNameChangeLoading: false};
    }
    return null;
  }

  public componentDidMount(): void {
    const {account, fetchAccount} = this.props;
    if (!account) {
      fetchAccount();
    }
  }

  componentDidUpdate(): void {
    const {updateContactPayload, resetEditProfile} = this.props;
    if (updateContactPayload && updateContactPayload.payloadStatus === PayloadStatus.OK) {
      this.updateContactSuccess();
      resetEditProfile();
    }
  }

  componentWillUnmount(): void {
    const {resetEditProfile} = this.props;
    resetEditProfile();
  }

  updateContactError(): JSX.Element | null {
    const {updateContactPayloadError, updateContactPayload} = this.props;
    if (updateContactPayloadError || (updateContactPayload && updateContactPayload.payloadStatus === PayloadStatus.NOK)) {
      return (
        <div className='l-col l-1of1'>
          <div className='content-box'>
            <h3 className='page-title_medium--red lighter left-text'>{I18n.translate('ProfileEdit.UpdateContact.Label.GeneralError')}</h3>
            <div className='text-small'>
              {I18n.translate('ProfileEdit.UpdateContact.Label.ErrorDescription')}
            </div>
          </div>
        </div>
      );
    }
    return null;
  }

  updateContactSuccess(): void {
    const {updateContactPayload, history} = this.props;
    if (updateContactPayload && updateContactPayload.payloadStatus === PayloadStatus.OK) {
      history.push({
        pathname: ProfileRoutes.PROFILE_HOME,
        state: I18n.translate('ProfileEdit.UpdateContact.Label.SuccessTitle')
      });
    }
  }

  renderEditAddressTitle(): JSX.Element {
    return (
      <div className='l-col l-1of1'>
        <div className='title-large'>
          {I18n.translate('ProfileEdit.EditAddress.Label.AddressEditTitle')}
        </div>
      </div>
    );
  }

  renderPrimaryAddressEditButton(): JSX.Element | null {
    if (SegmentService.getCode() !== Segment.SOHO) {
      return (
        <Button
          className={'button form_info_button'}
          handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.editBillingAddress(e)}
          label = {I18n.translate('ProfileEdit.Address.Button.Edit')}
          disabled={true}
        />
      );
    }
    return null;
  }

  renderBillingAddressEditButton(): JSX.Element | null {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    if ((billSettings && billSettings.paymentMethod !== PaymentMethodType.EBILL)) {
      return (
        <Button
          className={'button form_info_button'}
          handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.editBillingAddress(e)}
          label = {I18n.translate('ProfileEdit.Address.Button.Edit')}
          disabled={false}
        />
      );
    }
    return null;
  }

  renderAddressInformation(): JSX.Element {
    return (
      <React.Fragment>
        <div className='text-left page-title_medium--grey'>{I18n.translate('ProfileEdit.ChangeAddress.Label.InformationTitle')}</div>
        <div className='text-small left-text'><span className='adjustable_line_break'>{I18n.translate('ProfileEdit.ChangeAddress.Text.SegmentInformation')}</span></div>
      </React.Fragment>
    );
  }

  renderAddressNoChangeInformation(): JSX.Element | null {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const billSettings: Optional<BillSettings> = billInfo && billInfo.billSettings;
    if ((billSettings && billSettings.paymentMethod === PaymentMethodType.EBILL)) {
      return (
        <React.Fragment>
          <div className='text-left page-title_medium--grey'>{I18n.translate('ProfileEdit.ChangeAddress.Label.InformationTitle')}</div>
          <div className='text-small left-text'><span className='adjustable_line_break'>{I18n.translate('ProfileEdit.ChangeAddress.Text.Ebill.Information')}</span></div>
        </React.Fragment>
      );
    }
    return null;
  }

  editBillingAddress(e: React.MouseEvent<HTMLButtonElement>): void {
    const {account, history} = this.props;
    history.push({
      pathname: ProfileRoutes.CHANGE_BILLING_ADDRESS,
      state: account
    });
  }

  renderPrimaryAddress = (): JSX.Element | null => {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    const primaryAddress: Optional<Address> = account.primaryAddress;
    if (!primaryAddress) {
      return null;
    }
    return (
      <div className='l-col l-1of2 responsive_content_box'>
        <div className='content-box content-box--flexbox'>
          <div className='form'>
            <div className='form__label form__label--highlighted'>{I18n.translate('ProfileEdit.Label.Address')}</div>
            <div className='form-item'>
              <div className='form__text'>{primaryAddress.name === '' ? owner.name : primaryAddress.name}<br />{primaryAddress.streetName} {primaryAddress.streetNumber}<br />{primaryAddress.postalCode} {primaryAddress.town}</div>
            </div>
            {(SegmentService.getCode() === Segment.SOHO) ? this.renderAddressInformation() : null }
          </div>
          {this.renderPrimaryAddressEditButton()}
        </div>
      </div>
    );
  }

  renderBillingAddress = (): JSX.Element | null => {
    const {account} = this.props;
    const billInfo: Optional<BillInfo> = account.billInfo;
    const owner: Subscriber = account.owner;
    const billingAddress: Optional<BillingAddress> = billInfo && billInfo.billingAddress;
    const address: Optional<Address> = billingAddress && billingAddress.sameAsCustomerAddress ? account.primaryAddress : billingAddress && billingAddress.differentBillingAddress;
    if (!address) {
      return null;
    }
    return (
      <div className='l-col l-1of2 responsive_content_box'>
        <div className='content-box content-box--flexbox'>
          <div className='form'>
            <div className='form__label form__label--highlighted'>{I18n.translate('ProfileEdit.Label.BillingAddress')}</div>
            <div className='form-item'>
              <div className='form__text'>{address.salutation ? caseChange.pascalCase(address.salutation) : ''} {address.name === '' ? (owner.name) : address.name}<br />{address.streetName} {address.streetNumber}<br />{address.postalCode} {address.town}</div>
            </div>
            {this.renderAddressNoChangeInformation()}
          </div>
          {this.renderBillingAddressEditButton()}
        </div>
      </div>
    );
  }

  renderFormLabel(): JSX.Element {
    return (
      <div className='title-large extra_margin'>
        {I18n.translate('ProfileEdit.Label.ContactInformation')}
      </div>
    );
  }

  getPopupData = (name: string) => {
    const data: any = {};
    switch (name) {
      case ProfileConstants.EMAIL:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.EmailTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Label.EmailText');
        data.buttonLabel = I18n.translate('ProfileEdit.Tooltip.Button.EmailOk');
        return data;
      case ProfileConstants.PHONE:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.PhoneTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Label.PhoneText');
        data.buttonLabel = I18n.translate('ProfileEdit.Tooltip.Button.PhoneOk');
        return data;
      case ProfileConstants.LANGUAGE:
        data.title = I18n.translate('ProfileEdit.Tooltip.Label.LanguageTitle');
        data.text = I18n.translate('ProfileEdit.Tooltip.Label.LanguageText');
        data.buttonLabel = I18n.translate('ProfileEdit.Tooltip.Button.LanguageOk');
        return data;
      default:
        data.title = '';
        data.text = '';
        data.buttonLabel = I18n.translate('ProfileEdit.Tooltip.Button.Close');
        return data;
    }
  }

  displayTooltip(event: React.MouseEvent<HTMLButtonElement, MouseEvent>): void {
    const {hasTooltip} = this.state;
    const element: HTMLButtonElement = event.currentTarget as HTMLButtonElement;
    const id: string = element.id;
    event.persist();
    this.setState({
      hasTooltip: !hasTooltip,
      selectedTooltip: id
    });
  }

  renderTooltip = (): JSX.Element => {
    const {selectedTooltip} = this.state;
    const data: any = this.getPopupData(selectedTooltip);
    return (
      <Popup
        title = {data.title}
        data = {[data.text]}
        buttonLabel = {data.buttonLabel}
        onClick = { (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltip(e) }
      />
    );
  }

  renderEmailFormItem(): JSX.Element {
    const {email} = this.state.profile;
    const {account} = this.props;
    let className: string = 'form_input';
    let labelClassName: string = 'form__label form__text_field-label form__label__text text-left';
    let label: string = I18n.translate('ProfileEdit.Label.EmailAddress');
    if (email && !ValidationService.isValidEmail(email)) {
      className = 'form_input form_error';
      labelClassName = 'form__label form__text_field-label form_error';
      label = I18n.translate('ProfileEdit.Label.EmailError');
    }
    if (email && ValidationService.isValidEmail(email)) {
      className = 'form_input form_confirmation';
      labelClassName = 'form__label form__text_field-label form_confirmation';
      label = I18n.translate('ProfileEdit.Label.EmailSuccess');
    }
    return (
      <div className='form-item'>
        <Input
          name = {'email'}
          value = {email ? email : account.owner.email ? account.owner.email : ''}
          className = {className}
          onChange = {this.handleModelChange}
          labelClassName = {labelClassName}
          label = {label}
          tooltipId = {ProfileConstants.EMAIL}
          onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltip(e)}
        />
      </div>
    );
  }

  renderContactNumberFormItem(): JSX.Element {
    const {phone} = this.state.profile;
    const {account} = this.props;
    let className: string = 'form_input';
    let labelClassName: string = 'form__label form__text_field-label form__label__text text-left';
    let label: string = I18n.translate('ProfileEdit.Label.ContactNumber');
    if (phone && !ValidationService.isValidPhone(phone)) {
      className = 'form_input form_error';
      labelClassName = 'form__label form__text_field-label form_error';
      label = I18n.translate('ProfileEdit.Label.ContactNumberError');
    }
    if (phone && ValidationService.isValidPhone(phone)) {
      className = 'form_input form_confirmation';
      labelClassName = 'form__label form__text_field-label form_confirmation';
      label = I18n.translate('ProfileEdit.Label.ContactNumberSuccess');
    }
    return (
      <div className='form-item'>
        <Input
          type = {'number'}
          name = {'phone'}
          value = {phone ? phone : account.owner.phone ? account.owner.phone.replace(/\s/g, '') : ''}
          className = {className}
          labelClassName = {labelClassName}
          label = {label}
          tooltipId = {ProfileConstants.PHONE}
          onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltip(e)}
          onChange = {this.handleModelChange}
        />
      </div>
    );
  }

  handleModelChange = (fieldName: string, value: string): void => {
    const profile: ProfileEditForm = {...this.state.profile}
    profile[fieldName] = value;
    this.setState({profile});
  }

  renderLanguageFormItem(): JSX.Element {
    const {languageCode} = this.state.profile;
    const {account} = this.props;
    const languageOptions: Array<object> = LanguageService.getLanguageOptions();
    return (
      <div className='form-item'>
        <Select
          options={languageOptions}
          name={'languageCode'}
          value={languageCode ? languageCode : account.owner.language ? account.owner.language : ''}
          className={'form_input'}
          labelClassName = {'form__label form__text_field-label form__label__text text-left form__space_select_widget'}
          label = {I18n.translate('ProfileEdit.Language.Button.CorrespondenceLanguage')}
          tooltipId = {'LANGUAGE'}
          onClick={(e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => this.displayTooltip(e)}
          onChange = {this.handleModelChange}
        />
      </div>
    );
  }

  saveProfile(event: React.MouseEvent<HTMLButtonElement>): void {
    event.preventDefault();
    const {updateContact, account} = this.props;
    const {profile} = this.state;
    const owner: Subscriber  = account.owner;
    updateContact(profileService.getUpdateContactInput(profile, owner));
  }

  renderSave(): JSX.Element {
    const {email, phone} = this.state.profile;
    let disabled: boolean = false;
    if ((email && !ValidationService.isValidEmail(email)) || (phone && !ValidationService.isValidPhone(phone))) {
      disabled = true;
    }
    return (
      <div className='form-item'>
        <div className='form-item__button'>
          <Button
            className={'button extra_wide'}
            handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.saveProfile(e)}
            label = {I18n.translate('ProfileEdit.Button.Save')}
            disabled={disabled}
          />
        </div>
      </div>
    );
  }

  renderNameChangeInformation(): JSX.Element {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    if (!owner.email) {
      return (
        <div className='text-small centered-text'>
          {I18n.translate('ProfileEdit.ChangeName.Text.NoEmail')}
          <em>
            {I18n.translate('ProfileEdit.ChangeName.Text.NoEmailTitle')}
          </em>
        </div>
      );
    }
    if (owner.emailConfirmed) {
      return (
        <div className='text-small centered-text'>
          {I18n.translate('ProfileEdit.ChangeName.Text.UpdateEmail')}
          <em> {owner.email} </em>
          {I18n.translate('ProfileEdit.ChangeName.Text.EmailWithText')}
          <em> {I18n.translate('ProfileEdit.ChangeName.Text.EmailIdCheck')} </em>
        </div>
      );
    } else {
      return (
        <div className='text-small centered-text'>
          {I18n.translate('ProfileEdit.ChangeName.Text.UpdateName')}
          <em> {I18n.translate('ProfileEdit.ChangeName.Label.ValidateEmail')} </em>
          {I18n.translate('ProfileEdit.ChangeName.Text.EmailSend')}
          <em> {owner.email}</em>
        </div>
      );
    }
  }

  renderNameChange(): JSX.Element {
    const {account, sendVerificationEmailPayload, sendNameChangeInfoPayload, sendVerificationEmailPayloadError, sendNameChangeInfoPayloadError} = this.props;
    const {isNameChangeLoading} = this.state;
    const owner: Subscriber = account.owner;
    const disableStyle: any = {
      pointerEvents: 'none',
      opacity: 0.6
    }
    let successIdentidier: boolean = false;
    let errorIndentifier: boolean = false;
    if ((sendVerificationEmailPayload && sendVerificationEmailPayload.payloadStatus === PayloadStatus.OK) ||
      (sendNameChangeInfoPayload && sendNameChangeInfoPayload.payloadStatus === PayloadStatus.OK)) {
      successIdentidier = true;
    }

    if ((sendVerificationEmailPayload && sendVerificationEmailPayload.payloadStatus === PayloadStatus.NOK) || sendVerificationEmailPayloadError ||
      (sendNameChangeInfoPayload && sendNameChangeInfoPayload.payloadStatus === PayloadStatus.NOK) || sendNameChangeInfoPayloadError) {
      errorIndentifier = true;
    }
    const email: string = owner.email || '';
    return (
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box' style={(email === '' || !email) ? disableStyle : {}}>
        <div className={successIdentidier ?  'content-box content-box--bck_image content-box--img__mail' : 'content-box'}>
          <div className='title-large'>{owner.name}</div>
          {isNameChangeLoading ? <Loader /> : ''}
          {errorIndentifier ? this.renderEmailConfirmationError() : (successIdentidier ? this.renderEmailConfirmationSuccess() : this.renderNameChangeInformation())}
          <div className='centered-text'>
            <button
              style={{display: (successIdentidier || errorIndentifier) ? 'none' : ''}}
              className='button cta-button'
              onClick={(e: React.MouseEvent<HTMLButtonElement>) => this.changeNameRequest(e)}>{owner.emailConfirmed ? I18n.translate('ProfileEdit.ChangeName.Button.SendEmail') : I18n.translate('ProfileEdit.ChangeName.Label.SendEmailValidation')}</button>
          </div>
        </div>
      </div>
    );
  }

  renderEmailConfirmationError(): JSX.Element {
    return (
      <div className='text-small centered-text'>
        <span className='adjustable_line_break'>{I18n.translate('ProfileEdit.ChangeName.Label.ErrorTitle')}</span>
      </div>
    );
  }

  renderEmailConfirmationSuccess(): JSX.Element {
    const {account} = this.props;
    const owner: Subscriber = account.owner;
    return (
      <React.Fragment>
        <div className='text-small centered-text' key={0}>
          <span className='adjustable_line_break'>{I18n.translate('ProfileEdit.ChangeName.Label.SuccessTitle')}</span>
        </div>
        <div style={{display: owner.emailConfirmed ? '' : 'none'}} className='form__label form__label--highlighted' key={1}>
          {I18n.translate('ProfileEdit.ChangeName.Label.TipTitle')}
        </div>
        <div style={{display: owner.emailConfirmed ? '' : 'none'}} className='text-extra-small text-pad-r-40perc' key={2}>{I18n.translate('ProfileEdit.ChangeName.Label.TipDescription')}</div>
      </React.Fragment>
    );
  }

  changeNameRequest = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const {account, sendNameInfo} = this.props;
    const owner: Subscriber = account.owner;
    event.preventDefault();
    this.setState({
      isNameChangeLoading: true
    });
    if (owner.emailConfirmed) {
      sendNameInfo();
    } else {
      validateEmail();
    }
  }

  changeDateOfBirth = (event: React.MouseEvent<HTMLButtonElement>): void => {
    const url: string = 'https://www-t02.sunrise.ch/en/residential/help/kontakt/sunrise-shops.html';
    window.open(
      url,
      '_blank'
    );
  }

  renderDateOfBirthChange(): JSX.Element {
    const {account} = this.props;
    const birthDate: Optional<LocalDate> = account.owner.birthDate ? DateService.formatDate(account.owner.birthDate) : I18n.translate('Profile.Label.BirthdayNotAvailable');
    return (
      <div className='l-col-flexbox l-col-flexbox-even responsive_content_box'>
        <div className='content-box'>
          <div className='title-large'>{birthDate}</div>
          <div className='text-small centered-text text-pad-lr-70'>
            {I18n.translate('ProfileEdit.Text.DateOfBirth')}
            <span className='t-strong'> {I18n.translate('ProfileEdit.Text.DateOfBirthStrongText')} </span>
            {I18n.translate('ProfileEdit.Text.DateOfBirthNeedText')}
            <span className='t-strong'> {I18n.translate('ProfileEdit.Text.DateOfBirthNeedTextStrong')} </span>
          </div>
          <div className='centered-text'>
            <Button
              className={'button cta-button'}
              handleClick={(e: React.MouseEvent<HTMLButtonElement>) => this.changeDateOfBirth(e)}
              label = {I18n.translate('ProfileEdit.Button.ShopFinder')}
            />
          </div>
        </div>
      </div>
    );
  }

  render(): React.ReactNode {
    const {account} = this.props;
    const {hasTooltip, isEditProfileLoading} = this.state;
    if (isEditProfileLoading) {
      return (
        <div className='l-center-l'>
          <div className='l-grid'>
            {this.renderEditAddressTitle()}
            <Loader />
          </div>
        </div>
      );
    }
    if (!account) {
      return null;
    }

    return (
      <React.Fragment>
        <div className='l-center-l' key={0}>
          <div className='l-grid'>
            {this.renderEditAddressTitle()}
            <div>
              {this.renderPrimaryAddress()}
              {this.renderBillingAddress()}
            </div>
            {this.updateContactError()}
            <div className='l-col l-1of1'>
              <div className='content-box'>
                <div className='vertical_spacer x16'></div>
                {this.renderFormLabel()}
                <div className='form form_middle_box'>
                  {hasTooltip && this.renderTooltip()}
                  {this.renderEmailFormItem()}
                  {this.renderContactNumberFormItem()}
                  {this.renderLanguageFormItem()}
                  {this.renderSave()}
                </div>
              </div>
            </div>
            <div className='l-flexbox-row'>
              {this.renderNameChange()}
              {this.renderDateOfBirthChange()}
            </div>
          </div>
        </div>
        <StickyBar
          url='/' key={1}
          className='button extra_wide'
          backToLabel = {I18n.translate('ProfileEdit.ChangePassword.Button.BackToProfile')}/>
      </React.Fragment>
    )
  }
}

const mapStateToProps: any = ({ profileReducer }: any) => {
  return {
    account: profileReducer.account,
    updateContactPayload:  profileReducer.updateContactPayload,
    updateContactPayloadError: profileReducer.updateContactPayloadError,
    sendVerificationEmailPayload: profileReducer.sendVerificationEmailPayload,
    sendVerificationEmailPayloadError: profileReducer.sendVerificationEmailPayloadError,
    sendNameChangeInfoPayload: profileReducer.sendNameChangeInfoPayload,
    sendNameChangeInfoPayloadError: profileReducer.sendNameChangeInfoPayloadError
  };
};

const mapDispatchToProps: ((dispatch: Dispatch) => ActionCreatorsMapObject) = (dispatch) => {
  return bindActionCreators({ fetchAccount, updateContact, validateEmail, sendNameInfo, resetEditProfile}, dispatch);
};

export default connect<ProfileEditProps>(mapStateToProps, mapDispatchToProps)(ProfileEdit);
