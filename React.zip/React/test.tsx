import React from 'react';
import { RatePlanType } from '../../model/types.d';
import { ProductsStandard } from './Products/ProductsStandard';
import { ProductsPrepaid } from './Products/ProductsPrepaid';
import { ProductsInternetTV } from './Products/ProductsInternetTV';

class SubscriptionOverviewService {
    (ratePlansType: string, title: string, serviceId: string, subscriberName: string, balance: number, address: string): any {
    switch (ratePlansType) {
        case RatePlanType.MOBILE_POSTPAID:
        case RatePlanType.LANDLINE_PHONE:
            return <ProductsStandard title={title} serviceId={serviceId} subscriberName={subscriberName} />;
        case RatePlanType.MOBILE_PREPAID:
            return <ProductsPrepaid title={title} serviceId={serviceId} balance={balance} />;
        case RatePlanType.FIX_INTERNET:
        case RatePlanType.TV:
            return <ProductsInternetTV title={title} serviceId={serviceId} addressInternet={address} ratePlanstype={ratePlansType} />;
        default:
            return null;
    }
}

//json Bellow
getRateplansList(services: any): object {
    const list: Array<object> = [];
    if (services) {
        services.forEach((option: any) => {
            option.ratePlans.map((ids: any) => {
                const obj: object = {
                    'id': option.id,
                    'balance': option.balance,
                    'subscriberName': option.subscriber.name,
                    'ratePlansType': ids.type,
                    'ratePlansName': ids.name
                }
                list.push(obj);
            })
        });
    }
    return list;
}
}

export default new SubscriptionOverviewService(); 



services: [
    {
        "id:"1,
        "name": "abstract1",
        "subscriber" : {
            "name" : "AB"
        },
        "ratePlans" : [
            {
                "type" : "A1",
                "name" : "oLA"
            },
            {
                "type" : "B1",
                "name" : "BLA"
            }
        ]
     }
]