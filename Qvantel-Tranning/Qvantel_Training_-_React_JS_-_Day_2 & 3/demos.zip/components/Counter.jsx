import React, { Component } from "react";

class Counter extends Component {
  state = {
    count: 10
  };

  styles = {
    fontSize: "20px",
    fontWeight: "bold"
  };

  formatCount() {
    return this.state.count === 0 ? <h1>Zero</h1> : this.state.count;
  }

  getBadgeClasses() {
    let classes = "badge m-2 badge-";
    classes += this.state.count === 0 ? "warning" : "primary";
    return classes;
  }

  render() {
    return (
      <React.Fragment>
        <button className="btn btn-info btn-sm">Increment</button>
        <span style={this.styles} className={this.getBadgeClasses()}>
          {this.formatCount()}
        </span>
      </React.Fragment>
    );
  }
}

export default Counter;
