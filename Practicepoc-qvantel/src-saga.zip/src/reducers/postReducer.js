const initialState = {
  items: [],
  item: {}
};

export default function(state = initialState, action) {
  switch (action.type) {
    case "RECEIVE_API_DATA":
      return {
        // state mutates here
        ...state,
        items: action.data
      };
    case "RECEIVE_POST_CREATED":
      return {
        // state mutates here
        ...state,
        item: action.data
      };
    default:
      return state;
  }
}
