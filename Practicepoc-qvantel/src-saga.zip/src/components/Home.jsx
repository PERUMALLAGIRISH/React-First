import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from 'react-router-dom';

class Home extends Component {
  componentWillMount() {
    this.props.requestApiData();
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.newPost) {
      this.props.posts.unshift(nextProps.newPost); // updating an existing array
    }
  }

  render() {
    return (
      <div>
        <Link to={'/create'} className="btn btn-primary">Add To Product</Link>
        <br/><br/>
        <h4 className="text-muted">List of Products</h4>
        <table className="table table-striped">
          <thead>
            <tr className="table-header">
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th>Price</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {this.props.posts.map(post => (
              <tr key={post.id}>
                <td>{post.id}</td>
                <td>{post.name}</td>
                <td>{post.description}</td>
                <td>{post.price}</td>
                <td><button className="btn btn-info">Edit</button></td>
                <td><button className="btn btn-danger">Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

const mapStatetoProps = state => ({
  posts: state.posts.items,
  newPost: state.posts.item
});

const mapDispatchToProps = dispatch => {
  return {
    requestApiData: () => dispatch({ type: "REQUEST_API_DATA" })
  };
};

// map the state from the reducer to the props
export default connect(mapStatetoProps, mapDispatchToProps)(Home);
