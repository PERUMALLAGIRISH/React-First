import React, { Component } from "react";
import { createPostAction } from "../actions/action";
import { connect } from "react-redux";

class Create extends Component {
  state = {
    id: "",
    name: "",
    description: "",
    price: ""
  };

  handleChange = event => {
    const name = event.target.name;
    const value = event.target.value;

    this.setState({ [name]: value });
  };

  handleSubmit = event => {
    event.preventDefault();
    const post = {
      id: this.state.id,
      name: this.state.name,
      description: this.state.description,
      price: this.state.price
    };

    this.props.createPost(post);

    this.props.history.push('/home');
  };

  render() {
    return (
      <div>
        <h4 className="text-muted">Edit Products</h4>
        <hr/>
        <form onSubmit={this.handleSubmit}>
        <div class="form-group">
            <label>Enter Id:</label>
            <input
              type="text"
              name="id"
              class="form-control"
              value={this.state.id}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <div class="form-group">
            <label>Enter Name:</label>
            <input
              type="text"
              name="name"
              class="form-control"
              class="form-control"
              value={this.state.name}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <div class="form-group">
            <label>Enter Description:</label>
            <input
              type="text"
              name="description"
              class="form-control"
              value={this.state.description}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <div class="form-group">
            <label>Enter Price:</label>
            <input
              type="text"
              name="price"
              class="form-control"
              value={this.state.price}
              onChange={event => this.handleChange(event)}
            />
          </div>
          <button className="btn btn-info btn-lg">Submit</button>
        </form>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    createPost: post => dispatch(createPostAction(post))
  };
};

export default connect(null, mapDispatchToProps)(Create);
