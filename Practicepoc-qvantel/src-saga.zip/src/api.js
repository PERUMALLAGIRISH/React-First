export const fetchData = async () => {
  try {
    const response = await fetch(`http://localhost:5000/products`);
    const data = response.json();
    return data;
  } catch (e) {
    console.log(e);
  }
};

export const createPostData = async postData => {
  console.log("In create post api" + postData.body);
  const response = await fetch(`http://localhost:5000/products`, {
    method: "post",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(postData)
  });
  const data = response.json();
  return data;
};
