export const CREATE_POST_REQUESTED = "CREATE_POST_REQUESTED";

export const createPostAction = post => ({
  type: CREATE_POST_REQUESTED,
  post
});
