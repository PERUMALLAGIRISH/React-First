import React, { Component } from "react";
import "./App.css";

import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import { Provider } from "react-redux";

import Home from "./components/Home";
import Create from "./components/Create";

import store from "./store";

class App extends Component {
  render() {
    return (
      <div className="App">
      <Router>
      <Provider store={store}>
        <div>
        <h1 className="text-center">React Redux Saga CURD Application</h1>
        {/* <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
              <li className="nav-item">
                  <Link to={'/home'} className="nav-link">Home</Link>
                </li>
                <li className="nav-item">
                  <Link to={'/create'} className="nav-link">Create</Link>
                </li>
              </ul>
            </div>
          </nav> <br/> */}

        <Switch>
              <Route exact path='/home' component={ Home } />
              {/* <Route path='/edit/:id' component={ Edit } /> */}
              <Route path='/create' component={ Create } />
          </Switch>
{/* 
          <Create />
          <Post /> */}


        </div>
      </Provider>
      </Router>
      </div>
    );
  }
}

export default App;



