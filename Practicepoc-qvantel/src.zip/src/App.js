import React from 'react';
import './App.css';

import Home from './Components/Home';

function App() {
  return (
    <div>
      <h1 className="App">Welcome To Product Application!</h1>
      <h3 className="App">Product List</h3>
      <Home  />
    </div>
  );
}

export default App;
