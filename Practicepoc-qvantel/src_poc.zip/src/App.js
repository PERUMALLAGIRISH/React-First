import React from 'react';
import './App.css';

import Home from './Components/Home';
import AddList from './Components/AddList'

function App() {
  return (
    <div className="App">
      <AddList />
      <Home />
    </div>
  );
}

export default App;
